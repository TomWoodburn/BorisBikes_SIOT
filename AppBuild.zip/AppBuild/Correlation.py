# importing pandas as pd 
import pandas as pd 
  
# Making data frame from the csv file 
df = pd.read_csv("HistoricData.csv") 
  
# Printing the first 10 rows of the data frame for visualization 
ten = df[:10] 
print(ten)