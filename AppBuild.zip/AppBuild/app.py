import dash
import dash_html_components as html
import dash_core_components as dcc
print(dcc.__version__)

from dash.dependencies import Input, Output
#from dash.exceptions import PreventUpdate

import pandas as pd
import numpy
import datetime
import os
import numpy as np
from numpy.random import normal, seed

## Display all cell outputs
#from IPython.core.interactiveshell import InteractiveShell
#InteractiveShell.ast_node_interactivity = 'all'

# Visualization
#import matplotlib.pyplot as plt
#import seaborn as sns
#plt.style.use('bmh')

#import plotly.plotly as py
#import plotly.graph_objs as go


external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']

app = dash.Dash(__name__, external_stylesheets=external_stylesheets)

styles = {
    'pre': {
        'border': 'thin lightgrey solid',
        'overflowX': 'scroll'
    }
}


df =pd.read_csv('HistoricData.csv')
df = df[['Time','Time Elapsed days','Lux (raw)','Lux (norm)','Boris Bikes (raw)','Boris Bikes (norm)']]

df2 =pd.read_csv('BorisBikeAverages.csv')
df2 = df2[['Time (5 Mins)','2020-01-05','2020-01-07','2020-01-08','2020-01-09','2020-01-10','2020-01-11','Mean Average','STDEV.P','Lowest Value','Highest Value']]

df3 =pd.read_csv('CumulativeCorrelation.csv')
df3 = df3[['Time (5 Mins)','Norm Boris Bike Withdrawals','Norm Light Sensor']]

app.layout = html.Div([
    html.H1('Boris on a Bike - Web App'),
    dcc.Tabs(id="tabs", value='tab-1', children=[
        dcc.Tab(label='Data Visualisation', value='tab-1'),
        dcc.Tab(label='Data Actuation', value='tab-2'),
    ]),
    html.Div(id='tabs-content')
])

@app.callback(Output('tabs-content', 'children'),
            [Input('tabs', 'value')]
)       
def render_content(tab):
    if tab == 'tab-1':
        return  html.Div(children=[
    html.H3(children='Is there a correlation between the Boris Bike Availability at Humbolt Road, Fulham docking station and the brightness of the day?'),

    html.Div([
        dcc.Graph(
            figure=dict(
                
                data=[
                    dict(
                        x=df['Time'],
                        y=df['Lux (norm)'], #Lux (norm)
                        type='line',
                        name='Light Intensity (Lux)',
                        marker=dict(
                            color='rgb(55, 118, 100)'
                        )
                    ),
                    dict(
                        x=df['Time'],
                        y=df['Boris Bikes (norm)'],
                        type='line',
                        name='Boris Bikes Availability (n)',
                        marker=dict(
                            color='rgb(195, 49, 73)'
                        )
                    )
                ],
                layout=dict(
                    title='Graph One: Comparing Boris Bike Availability and Light Intensity over one week',
                    xaxis={'title': 'Date'},
                    yaxis={'title': 'Normalised Data'},
                    showlegend=True,
                    legend=dict(
                        x=0,
                        y=1.0
                    ),
                    
                )
            ),
            style={'display': 'inline-block', 'width': '100%', 'height': '100%'}), 
    ]),

    html.Div([
        dcc.Graph(
            figure=dict(
                
                data=[
                    dict(
                        x=df2['Time (5 Mins)'],
                        y=df2['Lowest Value'], #Lux (norm)
                        type='line',
                        name='Lowest Value',
                        marker=dict(
                            color='rgb(195, 49, 73)'
                        )
                    ),
                    dict(
                        x=df2['Time (5 Mins)'],
                        y=df2['Highest Value'],
                        type='line',
                        name='Highest Value',
                        marker=dict(
                            color='rgb(218, 159, 147)'
                        )
                    ),
                    dict(
                        x=df2['Time (5 Mins)'],
                        y=df2['Mean Average'],
                        type='line',
                        name='Mean Average',
                        marker=dict(
                            color='rgb(55, 118, 100)'
                        )
                    )
                ],
                layout=dict(
                    title='Graph Two: How does Boris Bike Availability change throughout the day at Humbolt Road, Fulham?',
                    xaxis={'title': 'Time (24 hours)'},
                    yaxis={'title': 'Number of Available Bikes'},
                    showlegend=True,
                    legend=dict(
                        x=0,
                        y=1.0
                    ),
                    
                )
            ),
            style={'display': 'inline-block', 'width': '100%', 'height': '100%'}), 
        ]),

        html.Div([
            dcc.Graph(
                figure=dict(
                    
                    data=[
                        dict(
                            x=df3['Time (5 Mins)'],
                            y=df3['Norm Boris Bike Withdrawals'], #Lux (norm)
                            type='line',
                            name='Cumulative Boris Bike Withdrawals',
                            marker=dict(
                                color='rgb(195, 49, 73)'
                            )
                        ),
                        dict(
                            x=df3['Time (5 Mins)'],
                            y=df3['Norm Light Sensor'],
                            type='line',
                            name='Cumulative Light Sensor Reading',
                            marker=dict(
                                color='rgb(218, 159, 147)'
                            )
                        )
                    ],
                    layout=dict(
                        title='Graph Three: The Cumulative Number of Boris Bikes withdrawn/docked Vs. The Cumulative Light Intensity - (Based on One Weeks Data)',
                        xaxis={'title': 'Time (24 hours)'},
                        yaxis={'title': 'Normalised Datasets'},
                        showlegend=True,
                        legend=dict(
                            x=0,
                            y=1.0
                        ),
                        
                    )
                ),
                style={'display': 'inline-block', 'width': '100%', 'height': '100%'}), 
            ])
        ])
    
    elif tab == 'tab-2':
        return html.Div(children=[
    html.H3(children='Bike Availability Prediction'),

    html.Div(children='''
        What was the weather like today?
    '''),

    html.Div([
        dcc.Dropdown(
            options=[
                {'label': 'Raining', 'value': 'Cloud'},
                {'label': 'Cloudy', 'value': 'Rain'},
                {'label': 'Sunny', 'value': 'Sun'}
            ],
            value='Sun',
        style={'display': 'inline-block', 'width': '50%', 'height': '50%'}),  
    ]),

    html.Div(children='''
        When do you want to hire a bike?
    '''),

    html.Div([
        dcc.RangeSlider(
        marks={i: '{}:00'.format(i) for i in range(0, 23)},
        min=0,
        max=23,
        value=[-3, 4]
        )
    ]),

        html.Div(children='''--
        
        '''),

        html.Div(children='''
        The predicted number of Available Bikes at this time is: 7
        ''')
        ])

if __name__ == '__main__':
    app.run_server(debug=True) #Change this!