import json

import csv
import time
import datetime

import glob

import os
import datetime


#def modification_date(filename):
#    t = os.path.getmtime(filename)
#    return datetime.datetime.fromtimestamp(t)

outputFile = open("convertedDataIt1201.csv", "w")
outputWriter = csv.writer(outputFile)
outputWriter.writerow(["Time","","", "Key","","Value","Modified"])

#dates = [0301,0401,0501,0701,0801,0901,1001]
data_folder = "json_data/1201"

for filename in glob.iglob(data_folder+"/*.json"):

    sourceFile = open(filename, "r")

    json_data = json.load(sourceFile)

    start_time = os.path.getmtime(filename)

    for aStation in json_data["additionalProperties"]:
        newRow =[]
        newRow.append(start_time)
        for Attribute in aStation:

            newRow.append(aStation[Attribute])

        outputWriter.writerow(newRow)

sourceFile.close()
outputFile.close()