import json

import csv
import time
import datetime

import glob

import os
import datetime

#import numpy as np

#def modification_date(filename):
#    t = os.path.getmtime(filename)
#    return datetime.datetime.fromtimestamp(t)

outputFile = open("convertedDataIt0505to1001.csv", "w")
outputWriter = csv.writer(outputFile)
outputWriter.writerow(["Time","","", "Key","","Value","Modified"])

#dates = ["0301","0401","0501","0701","0801","0901","1001"]
dates = ["0501","0701","0801","0901","1001"]
number = [285,277,272,290,283]
#data_folder = "json_data/".dates

for date in dates:
    #datajason = open("json_data/{}"/) 
    dataindex = dates.index(date)
    entries = number[dataindex]+1
    dummy = 1
    entrylist = []
    while dummy<entries:
        entrylist.append(dummy)
        dummy+=1
  
    for FileNumber in entrylist:

        JasonData = open(r"json_data/{}/TFL_BikePoint_it1_{}.json".format(date,FileNumber), "r")



        print(JasonData)

        json_data = json.load(JasonData)

        #json_data = json.load(sourceFile)

        start_time = os.path.getmtime(r"json_data/{}/TFL_BikePoint_it1_{}.json".format(date,FileNumber))

        for aStation in json_data["additionalProperties"]:
            newRow =[]
            newRow.append(start_time)
            for Attribute in aStation:

                newRow.append(aStation[Attribute])

            outputWriter.writerow(newRow)

#sourceFile.close()
outputFile.close()