for ((i=1;i<1000;i++)) do
    curl -o "json_data/Demonstration/TFL_BikePoint_it1_"$i".json" "https://api.tfl.gov.uk/BikePoint/BikePoints_761";
    sleep 50;
done
